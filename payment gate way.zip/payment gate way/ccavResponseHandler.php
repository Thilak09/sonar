<?php include( 'Crypto.php' )?>

<?php
include( 'connection.php' );
session_start();

error_reporting( 0 );
$workingKey = '2742859DAC75A46C39BE36831008C11A';

//Working Key should be provided here.
$encResponse = $_POST[ 'encResp' ];
//This is the response sent by the CCAvenue Server
$rcvdString = decrypt( $encResponse, $workingKey );
//Crypto Decryption used as per the specified working key.
$order_status = '';

$decryptValues = explode( '&', $rcvdString );
$dataSize = sizeof( $decryptValues );
for ( $i = 0; $i < $dataSize; $i++ ) {
    $information = explode( '=', $decryptValues[ $i ] );
    if ( $i == 3 )	$order_status = $information[ 1 ];
    if ( $i == 1 )	$tracking_id = $information[ 1 ];
    if ( $i == 0 )	$order_id = $information[ 1 ];
    if ( $i == 2 ) $bank_ref_no = $information[ 1 ];
    if ( $i == 10 ) $amount = $information[ 1 ];
    if ( $i == 35 ) $mer_amount = $information[ 1 ];
    if ( $i == 42 ) $trans_fee = $information[ 1 ];
    if ( $i == 43 ) $service_tax = $information[ 1 ];
    if ( $i == 5 ) $payment_mode = $information[ 1 ];
}

if ( $order_status === 'Success' ) {
    $timess = date( 'd-m-Y h:i:s a' );
     $sql = "UPDATE `student_order` SET `payment_status`='".	$order_status."',`payment_time`='".$timess."',`tracking_id`='".$tracking_id."',`bank_ref_no`='".$bank_ref_no."',`amount`='".$amount."',`mer_amount`='".$mer_amount."',`trans_fee`='".$trans_fee."',`payment_mode`='".$bank_ref_no."', `service_tax`='".$service_tax."',`order_status`='".$order_status."' WHERE `id`='".$order_id."'";
    $result = $conn->query( $sql );
    $_SESSION[ 'order_id' ] = $order_id;
    //echo '<br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.';
    header( 'location:success.php' );
} else if ( $order_status === 'Aborted' ) {
    header( 'location:fail.php' );
    //echo '<br>Thank you for shopping with us.We will keep you posted regarding the status of your order through e-mail';

} else if ( $order_status === 'Failure' ) {
    header( 'location:fail.php' );
    // echo '<br>Thank you for shopping with us.However,the transaction has been declined.';
} else {
    header( 'location:fail.php' );
    // echo '<br>Security Error. Illegal access detected';

}

// echo '<br><br>';

// echo '<table cellspacing=4 cellpadding=4>';
// for ( $i = 0; $i < $dataSize; $i++ ) {
//     $information = explode( '=', $decryptValues[ $i ] );
//     echo '<tr><td>'.$information[ 0 ].'</td><td>'.urldecode( $information[ 1 ] ).'</td></tr>';
// }

// echo '</table><br>';
// echo '</center>';
?>