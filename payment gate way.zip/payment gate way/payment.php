<?php include( 'include/header.php' );
$CCA_MERCHANT_ID = 750606;

$revalution= '';
$revalutionamount= 0;
if ( isset( $_POST[ 'revalution' ] ) )
 {
  
$revalution = implode(",",$_POST['revalution']);
    $revalutionamount = count($_POST['revalution'])*400;
}
$retotalling ='';
$retotallingamount=0;
if ( isset( $_POST[ 'retotalling' ] ) )
 {

$retotalling = implode(",",$_POST['retotalling']);
    $retotallingamount = count($_POST['retotalling'])*200;
}

$totalfee =  $revalutionamount + $retotallingamount;
$penalty = 0;
$tatkal = 0;
?>

<body onload='overlay();'>
    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg' class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'>
            <div class='col-md-12 color-1  '>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                         <h2>HONOURS DEGREE COURSES, JUNE 2022 EXAMINATIONS</h2>
                        <h5>REVALUTION / RETOTALLING APPLICATION FORM - FINAL SEMESTER </h5>
                    </div>
                    <div class='col-md-12'>

                        <?php
$sql = "SELECT * FROM `subject_list` where `reg_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();
$name = $row[ 'name' ];
?>
                        <div class='row'>
                            <div class='col-md-12'>
                                <div class='row'>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Register No:</label>
                                        <div><b><?php echo $regno;
?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Student Name:</label>
                                        <div><b><?php echo $row[ 'name' ];
?></b>
                                        </div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <label>DOB:</label>
                                        <div><b><?php  echo $row[ 'dob' ];
?></b></div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <label>Mobile No:</label>
                                        <div><b><?php echo $mobile_no=$row[ 'mobile' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Email ID:</label>
                                        <div><b><?php echo $email= $row[ 'email' ] ?></b>
                                        </div>
                                    </div>
                                   
                                    <div class='col-md-4 inlinediv'>
                                        <label>Course Name:</label>
                                        <div><b><?php  echo $row[ 'course_name' ];
?></b>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            
                        </div>
                        <br> <br>
                        <h3>Details</h3>
                        Revaluation Paper: <?php echo $revalution; ?><br>
                        Retotalling Paper: <?php echo $retotalling; ?><br>
                        Fees Amount : <?php echo $totalfee; ?><br>
<?php
$randomid = time().rand( 111111, 999999 );
$timess = date( 'd-m-Y h:i:s a' );
$date = date( 'd-m-Y' );
$randomid = $randomid;
$order_sql = "INSERT INTO `student_order`(`register_no`, `name`, `revalution_paper`, `retotalling_paper`, `payment_id`, `total_fee`, `payment_status`, `time`, `date`, `email`, `mobile`,`amount`, `mer_amount`,`penalty`, `tatkal`) VALUES ('".$regno."','".$name."','".$revalution."','".$retotalling."','".$randomid."','".$totalfee."','','".$timess."','".$date."','".$email."','".$mobile_no."','','','".$penalty."','".$tatkal."')";
$result = $conn->query( $order_sql );
$last_id = mysqli_insert_id( $conn );
?>

                       


                       
                        <p>Payment Time & Date: <?php echo $timess;
?></p>
                        <?php

if ( $result ) {
    ?><form name='frmPayment' action='ccavRequestHandler.php' method='POST'>
                            <tr>

                                <td><input type='hidden' value=<?php echo $randomid;
    ?> name='tid' id='tid' readonly />
                                </td>
                            </tr>
                            <input type='hidden' name='merchant_id' value='<?php echo $CCA_MERCHANT_ID; ?>'>
                            <input type='hidden' name='language' value='EN'>
                            <input type='hidden' name='order_id' value='<?php echo $last_id;?>'>
                            <input type='hidden' name='amount' value='<?php echo $totalfee; ?>'> <input type='hidden' name='merchant_param1' value='<?php echo $regno; ?>'>

                            <!-- <input type = 'hidden' name = 'amount' value = '10'> -->
                            <input type='hidden' name='currency' value='INR'>
                            <input type='hidden' name='redirect_url' value='https://tndalucoe.in/revalution_otfs/ccavResponseHandler.php'>
                            <input type='hidden' name='cancel_url' value='https://tndalucoe.in/revalution_otds/ccavResponseHandler.php'>

                            <div>
                                <input type='hidden' name='billing_name' value=<?php echo $name;
    ?> class='form-field' Placeholder='Billing Name'>
                                <input type='hidden' name='billing_address' value='' class='form-field' Placeholder='Billing Address'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_state' value='' class='form-field' Placeholder='State'>
                                <input type='hidden' name='billing_zip' value='' class='form-field' Placeholder='Zipcode'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_country' value='' class='form-field' Placeholder='Country'>
                                <input type='hidden' name='billing_tel' value=<?php echo $mobile_no ?> class='form-field' Placeholder='Phone'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_email' value=<?php echo $email ?> class='form-field' Placeholder='Email'>
                            </div>

                            <p> <input type='checkbox' name='terms' checked onclick='return false'> I hereby declare
                                that all the details given above are correct to the best of my
                                knowledge, If any discrepancies, necessary actions shall be initiated by the University
                                against me.
                            </p>
                            <div>
                                <button class='btn btn-secondary' type='reset' onclick='history.back()'>BACK</button>
                                <button class='btn btn-primary' type='submit'>Pay Now</button>
                            </div>
                        </form>

                        <?php
}
?>
                    </div>

                </div>

            </div>
            <?php
?>

        </div>
    </div>
    <!--- Count Down End -->

</body>
<script>
    function goBack() {
        window.location.hash = window.location.lasthash[window.location.lasthash.length - 1];
        //blah blah blah
        window.location.lasthash.pop();
    }
</script>
<?php include( 'include/footer.php' );
?>