<?php include( 'include/header.php' );
?>

<body onload='overlay();'>

    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='https://coe.tndalu.ac.in/Images/logo.jpg'
                        class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'>
            <div class='col-md-12 color-1'>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12 text-center'><br>
                        <h2 style='color:red;'>Payment Fail</h2>
                    </div>
                    <div class='col-md-12 text-center'><br>
                        <h3>Sorry, your payment had failed. The payment was declined.</h3><br>
                        <a href='index.php'>Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--- Count Down End -->

</body>

<?php include( 'include/footer.php' );
?>