<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'Mail/PHPMailer.php';
require 'Mail/SMTP.php';
require 'Mail/Exception.php';

//Load Composer's autoloader
//require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer();

try {
    $mail->isSMTP();

//Enable SMTP debugging

$mail->SMTPDebug = 2;

//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';

//Set the hostname of the mail server
$mail->Host = 'email-smtp.us-west-2.amazonaws.com';

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
// I tried PORT 25, 465 too
$mail->Port = 587;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = 'AKIA3KS2HU6B4E62GYGC';

//Password to use for SMTP authentication
$mail->Password = 'BNMgJ4t+CkP2ePHYC6CoHdCeajynYWIuw2Tbtgl5iuKV';

//Set who the message is to be sent from
$mail->setFrom('support@gofloaters.com', 'TNDALU');

//Set who the message is to be sent to
$mail->addAddress('hi@radhakrishnan.in', 'receiver');

//Set the subject line
$mail->Subject = 'PHPMailer GMail SMTP test';


$mail->Body = 'This is a plain-text message body';
//Replace the plain text body with one created manually
$mail->AltBody = 'This is a plain-text message body';
$mail->addAttachment('pdf/Thirupavai-PDF.pdf' );
//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
} //Attachments
    //
//Add attachments   //Optional name
?>