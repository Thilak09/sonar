<?php
 session_start(); 
print_r($_SESSION);
unset($_SESSION["regno"]);
session_destroy();   
header('location:login.php');
?>