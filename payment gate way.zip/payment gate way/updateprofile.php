<?php
include( 'connection.php' );

session_start();
$regno = $_SESSION[ 'regno' ];
if ( !$regno ) {
    header( 'location:logout.php' );
}
$mobile_no = $_POST[ 'mobile' ];
$email = $_POST[ 'email' ];

$sql = "UPDATE `subject_list` SET `mobile`='".$mobile_no."',`email`='".$email."' WHERE `reg_no`='".$regno."'";
$result = $conn->query( $sql );
if ( $result )
 {

    header( 'location:index.php' );
}
?>