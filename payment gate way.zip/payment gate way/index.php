<?php include( 'include/header.php' );
?>

<body onload='myFunctionInternal();'>
    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg' class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'></div>
        <div class='col-md-12 text-right'><a href='logout.php'>Logout</a></div>
    </div>
    <?php
$sql = "SELECT * FROM `subject_list` where `reg_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();  $reg_no = $row[ 'reg_no' ];
    $mobile_no = $row[ 'mobile' ];
$name = $row[ 'name' ];
$email = $row[ 'email' ];
    
    $course_name= $row[ 'course_name' ];
    
?>
    <div class='container '>
        <div class='row'>
            <div class='col-md-12 color-1  '>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <h2>Honours Degree Courses (other than final semester), June 2022 Examination </h2>
                        <h5>Revaluation / Retotalling Application Form (other than final semester)</h5>
                    </div>
                    <div class='col-md-12'>
                        <form action='updateprofile.php' method='post'>

                            <div class='row'>
                                <div class='col-md-4 inlinediv'>
                                    <label>Register No:</label>
                                    <div><b><?php echo $regno;
?></b>
                                    </div>
                                </div>
                                <div class='col-md-4 inlinediv'>
                                    <label>Student Name:</label>
                                    <div><b><?php echo $row[ 'name' ];
?></b>
                                    </div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>DOB:</label>
                                    <div><b><?php  echo $row[ 'dob' ];
?></b></div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>Mobile No:</label>
                                    <div><?php echo $mobile_no; ?>
                                    </div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>Email ID:</label>
                                    <div><?php echo $email; ?>
                                    </div>
                                </div>

                                <div class='col-md-12 inlinediv'>
                                    <label>Course Name:</label>
                                    <div><b><?php echo $course_name;
?>
                                        </b>
                                    </div>
                                    
                                </div>

                        
                            </div>
                        </form>
                    </div>

                </div>
            </div>
            <?php $ordersql = "SELECT * FROM `student_order` WHERE `register_no`='".$regno."' and `order_status`='Success'";
        $orderresult = $conn->query( $ordersql );

        if ( $orderresult->num_rows > 0 ) {
            // output data of each row

            ?>
            <div class='col-md-12 color-1'>

                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <table class='table'>
                            <tr>
                                <th>Payment ID </th>

                                <th>
                                    Time & Date </th>
                                <th>Receipt </th>
                            </tr>
                            <?php  while( $orderrow = $orderresult->fetch_assoc() ) {
                ?>
                            <tr>
                                <td><?php echo $orderrow[ 'id' ];
                ?></td>
                                <td><?php echo $orderrow[ 'payment_time' ];
                ?></td>
                                <td><a target='_blank' href="viewreceipt.php?order_id=<?php echo $orderrow[ 'id' ];
                ?>">Download</td>
                            </tr>

                            <?php  }
                ?>
                        </table>
                    </div>
                </div>
            </div>
            <?php

            } else {
                
                    ?>
            <div class='col-md-12 color-1'>
                  
                <form action='payment.php' id='payment' method='post'>
                    <div class='box-layout box-shadow row'>

                        <div class='col-md-7'>
                            <h4>Failed Subject particulars</h4>
<p> [Select the Revaluation checkbox / Re-Totalling checkbox given below which you want to apply]</p>
                            <table class='table'>

                                <tr>

                                    <th>S No</th>


                                    <th>Subject Code</th>
                                    <th>Subject Name</th>
                                    <th>Revaluation  </th>
                                    <th>Retotalling</th>
                                </tr>

                                <?php
                    $subjectssql = "SELECT * FROM `subject_list` WHERE `reg_no` = '$regno'";
                    $subjectsresult = $conn->query( $subjectssql );
                    $currentsubjects = '';
                    $i = 1;
                    while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
                       
                        ?> <tr>
                                    <td> <?php echo $i;
                        ?></td>
                                    <td> <?php echo $subjectsrow[ 'subject_code' ];
                        ?></td>

                                    <td> <?php echo $subjectsrow[ 'subject_name' ];
                        ?></td>
                                    <td>
                                        <input type='checkbox' id='<?php echo $subjectsrow[ 'subject_code' ]; ?>' name='revalution[]' title='<?php echo $subjectsrow[ 'subject_code' ]; ?>' value='<?php echo $subjectsrow[ 'subject_code' ]; ?>' amount='400' onchange='myFunctionInternal()'>
                                    </td>
                                    <td>
                                        <input type='checkbox' id='<?php echo $subjectsrow[ 'subject_code' ]; ?>' name='retotalling[]' title='<?php echo $subjectsrow[ 'subject_code' ]; ?>' value='<?php echo $subjectsrow[ 'subject_code' ]; ?>' amount='200' onchange='myFunctionInternal()'>
                                    </td>
                                </tr>
                                <?php  $i++;
                    }

                    ?>
                            </table>


                        </div>
                        <div class='col-md-5'>
                            Revaluation Fees Per Subjects (Rs.400 / Subject): <b id='revaluation-total'></b><br>
                          Retotalling Fees Per Subjects  (Rs.200 / Subject): <b id='retotalling-total'></b><br>
                            Total: Rs. <b id='seats-total'></b><br>

                        </div>
                   
                    <div class='col-md-6'></div>
                    <div class='col-md-6 text-right'> <br>
                        <input type="submit" class="submit" value="Register Now">
                    </div> </div>
                </form>
               

            </div>
            <?php  
        }                     ?>

        </div>
    </div>
    <!--- Count Down End -->

</body>
<script src='https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js' crossorigin='anonymous' referrerpolicy='no-referrer'></script>

<script>
    function myFunctionInternal() {

        var seatsTotal = document.getElementById('seats-total');
        var revaluationTotal = document.getElementById('revaluation-total');
        var retotallingTotal = document.getElementById('retotalling-total');
        var examamount = document.getElementById('examamount');
        var semamount = document.getElementById('semamount');
        var othersubjectslen = 0;
        var othersubjectArray = 0;




        var revalution = new Array();
        $.each($("input[name='revalution[]']:checked"), function() {
            revalution.push($(this).val());
        });
        var retotalling = new Array();
        $.each($("input[name='retotalling[]']:checked"), function() {
            retotalling.push($(this).val());

        });
revaluationTotal.innerHTML = revalution.length; 
        retotallingTotal.innerHTML = retotalling.length; 
seatsTotal.innerHTML
        seatsTotal.innerHTML = (retotalling.length * 200) + (revalution.length * 400);

    }
</script>


<?php include( 'include/footer.php' );