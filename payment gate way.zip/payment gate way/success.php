<?php include( 'include/header.php' );
$regno = $_SESSION[ 'regno' ];
$order_id = $_SESSION[ 'order_id' ];
//$order_id = 1;
if ( !$regno ) {
    header( 'location:logout.php' );
}

?>

<body onload='overlay();'>

    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg' class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'>
            <div class='col-md-12 color-1'>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <h2>HONOURS DEGREE COURSES, JUNE 2022 EXAMINATIONS</h2>
                        <h5>REVALUTION / RETOTALLING / XEROX COPY OF ANSWER SCRIPT APPLICATION FORM - FINAL SEMESTER </h5>
                    </div>
                    <div class='col-md-12'>

                        <?php
 $sql = "SELECT * FROM `student_order` WHERE `id`='".$order_id."' and `order_status`='Success'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();
$name = $row[ 'name' ];
?>
                        <div class='row'>
                            <div class='col-md-12'>
                                <div class='row'>
                                    <div class='col-md-12 inlinediv'>
                                        <label>Register No:</label>
                                        <b><?php echo $regno;
?></b><br>
                                        <label>Student Name:</label>
                                        <b><?php echo $row[ 'name' ];
?></b> <br><label>Mobile No:</label> <b><?php echo $mobile_no=$row[ 'mobile' ] ?></b><br>
                                        <label>Email ID:</label>
                                        <b><?php echo $email= $row[ 'email' ] ?></b>
                                     <br>
                                <label>Revaluation Paper :</label>
                               <b><?php echo $row[ 'revalution_paper' ] ?></b>
                              
                                <br>
                                <label>Retotalling Paper :</label>
                               <b><?php echo $row[ 'retotalling_paper' ] ?></b>
                                 <br>
                                <label>Fees Amount :</label>
                                <b><?php echo $row[ 'total_fee' ] ?></b>
                               
        </div>
    </div>
    <!--- Count Down End -->

</body>

<?php include( 'include/footer.php' );
?>