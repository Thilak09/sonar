<?php
include( 'connection.php' );
session_start();


$filename = 'TNDALU Honours - ALL Data';
$date = date( 'd-m-Y' );
$file_ending = 'xls';
//header info for browser
header( 'Content-Type: application/xls' );
header( "Content-Disposition: attachment; filename=$filename.xls" );
header( 'Pragma: no-cache' );
header( 'Expires: 0' );
/*******Start of Formatting for Excel*******/
//define separator ( defines columns in excel & tabs in word )
$sep = "\t";
$sep2 = "\n";
//tabbed character
//start of printing column names as names of MySQL fields
echo "Order ID" . "\t";
echo "Date" . "\t";
echo "Course" . "\t";
echo "Register No." . "\t";	
echo "Name" . "\t";
echo "DOB" . "\t";
echo "Other Subjects" . "\t";
echo "Final_Year Student" . "\t";
echo "Optional" . "\t";
echo "Subject Code" . "\t";	
echo "Semester" . "\t";
echo "Internal_status" . "\t";
echo "External_Status" . "\t";
echo "Blind" . "\t";
echo "Readmission" . "\t";
echo "Readmission Year" . "\t";
echo "Readmission Semester" . "\t";
echo "Student_status" . "\t";
echo "current_semester" . "\t";
echo "Subject Name" . "\t";	
echo "Clinical" . "\t";
echo "Mobile No" . "\t";	
echo "Email" . "\t";
echo "Centre Code" . "\t";	
echo "College Name" . "\t";	
echo "Batch" . "\t";	
echo "Regulation" . "\t";
echo "Address" . "\t";	
echo "Aadhaar" . "\t";
echo "Exam Fee" . "\t";
echo "Application Fee" . "\t";
echo "Statement of Marks" . "\t";
echo "Provisional Certificate" . "\t";
echo "Consolidated Statement of Mark" . "\t";
echo "Convocation Fees" . "\t";
echo "Amount" . "\t";
echo "Penalty" . "\t";
echo "Tatkal" . "\t";
echo "Image" . "\t";
print( "\n" );
//end of printing column names
//start while loop to get data
$schema_insert = '';
$subjectsql = "SELECT student_order_n.id,students.course, student_order_n.id,student_order_n.subjects, students.adhaar_no, students.address, students.readmission_year, students.readmission_semester, student_order_n.date, subject_list.register_no, subject_list.name, subject_list.dob, subject_list.final_year_student, subject_list.optional_subjects, subject_list.subject_code, subject_list.semester, enrolled_subjects.internal_status, enrolled_subjects.external_status, subject_list.blind, subject_list.readmission, subject_list.student_status, subject_list.current_semester,subject_list.subject_name, subject_list.clinical,  students.mobile_no, students.email, subject_list.centre_code, subject_list.college_name, subject_list.batch, subject_list.regulation, student_order_n.exam_fee, student_order_n.application_fee, student_order_n.statement_of_marks,student_order_n.provisional_certificate, student_order_n.consolidated_statement_of_mark, student_order_n.convocation_fees, student_order_n.total_fee, student_order_n.penalty,student_order_n.tatkal, subject_list.status FROM subject_list,enrolled_subjects,students,student_order_n WHERE student_order_n.id=enrolled_subjects.order_id and students.register_no=subject_list.register_no and subject_list.subject_code = enrolled_subjects.subject_code and student_order_n.register_no=students.register_no and student_order_n.order_status='Success' and enrolled_subjects.status='1' GROUP BY subject_list.id ORDER BY student_order_n.id";


$subjectresult = $conn->query( $subjectsql );
while( $subjectsrow = $subjectresult->fetch_assoc() ) {
$course= $subjectsrow['course'];
$register_no=$subjectsrow['register_no'];
$name=$subjectsrow['name'];
$adhaar_no=$subjectsrow['adhaar_no'];
$adhaar_no = str_replace(" ", "",  $adhaar_no); 
$address=$subjectsrow['address'];
$address = str_replace("\\n", " ",  $address); 
$address = str_replace("\\r", " ",  $address);
$address = str_replace("\r\n", " ",  $address);
$address = str_replace("\n\r", " ",  $address);
$address = str_replace("\r", " ",  $address); 
$address = str_replace("\n", " ",  $address); 
$readmission_year=$subjectsrow['readmission_year'];
$readmission_semester=$subjectsrow['readmission_semester'];
$dob=$subjectsrow['dob'];
$date=$subjectsrow['date'];
$subjects=$subjectsrow['subjects'];
$final_year_student=$subjectsrow['final_year_student'];
$optional_subjects=$subjectsrow['optional_subjects'];
$subject_code=$subjectsrow['subject_code'];
$semester=$subjectsrow['semester'];
$internal_status=$subjectsrow['internal_status'];
$external_status=$subjectsrow['external_status'];
$id=$subjectsrow['id'];
$blind=$subjectsrow['blind'];
$readmission=$subjectsrow['readmission'];
$student_status=$subjectsrow['student_status'];
$current_semester=$subjectsrow['current_semester'];
$subject_name=$subjectsrow['subject_name'];
$clinical=$subjectsrow['clinical']; 
$mobile_no=$subjectsrow['mobile_no'];
$email=$subjectsrow['email'];
$centre_code=$subjectsrow['centre_code'];
$college_name=$subjectsrow['college_name'];
$batch=$subjectsrow['batch'];
$regulation=$subjectsrow['regulation'];
$exam_fee=$subjectsrow['exam_fee']; 
$application_fee=$subjectsrow['application_fee']; 
$statement_of_marks=$subjectsrow['statement_of_marks']; 
$provisional_certificate=$subjectsrow['provisional_certificate']; 
$consolidated_statement_of_mark=$subjectsrow['consolidated_statement_of_mark']; 
$convocation_fees=$subjectsrow['convocation_fees']; 
$amount=$subjectsrow['total_fee'];
$convocation_fees=$subjectsrow['convocation_fees']; 
$amount=$subjectsrow['total_fee'];
$penalty=$subjectsrow['penalty']; 
$tatkal=$subjectsrow['tatkal']; 
$image=$register_no."."."jpg"; 

$schema_insert .= "$id".$sep."$date".$sep."$course".$sep."$register_no".$sep."$name".$sep."$dob".$sep."$subjects".$sep."$final_year_student".$sep."$optional_subjects".$sep."$subject_code".$sep."$semester".$sep."$internal_status".$sep."$external_status".$sep."$blind".$sep."$readmission".$sep."$readmission_year".$sep."$readmission_semester".$sep."$student_status".$sep."$current_semester".$sep."$subject_name".$sep."$clinical".$sep."$mobile_no".$sep."$email".$sep."$centre_code".$sep."$college_name".$sep."$batch".$sep."$regulation".$sep."$address".$sep."$adhaar_no".$sep."$exam_fee".$sep."$application_fee".$sep."$statement_of_marks".$sep."$provisional_certificate".$sep."$consolidated_statement_of_mark".$sep."$convocation_fees".$sep."$amount".$sep."$penalty".$sep."$tatkal".$sep."$image".$sep."\n";
}
print( trim( $schema_insert ) );
print "\n";
?>