<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'tndalu_dec';

// Create connection
$conn = new mysqli( $servername, $username, $password, $dbname );
// Check connection
if ( $conn->connect_error ) {
    die( 'Connection failed: ' . $conn->connect_error );
}

date_default_timezone_set( 'Asia/Kolkata' );
$date = date( 'd-m-Y h:i:s a' );
// function get_the_indian_time()
// {
// $time_res = mysql_query( 'SELECT NOW()' );
// $time_row = mysql_fetch_array( $time_res );
// $curr_date = $time_row[ 0 ];

// $final_time_res = mysql_query( "SELECT CONVERT_TZ('$curr_date','+00:00','+00:00')" );
// $final_time_row = mysql_fetch_array( $final_time_res );
// $time_res = $final_time_row[ 0 ];
//return $time_res;
// return $time_res;
// }
?>