<?php include( 'include/header.php' );
?>

<body onload='myFunctionInternal();'>
    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg'
                        class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'></div>
        <div class='col-md-12 text-right'><a href='logout.php'>Logout</a></div>
    </div>
    <div class='container '>
        <div class='row'>
            <div class='col-md-12 color-1  '>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <h3> HONOURS DEGREE COURSES ,DECEMBER 2022 EXAMINATIONS</h3>
                        <h5>EXAMINATION APPLICATION FORM</h5>
                    </div>
                    <div class='col-md-9'>
                        <form action='updateprofile.php' method='post'>
                            <?php
$sql = "SELECT * FROM `students` where `register_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();
$current_sem = $row[ 'current_semester' ];
$student_status = $row[ 'student_status' ];
$adhaar_no = $row[ 'adhaar_no' ];
$adhaar_url = $row[ 'adhaar_url' ];
$photo_url = $row[ 'photo_url' ];
$readmission = $row[ 'readmission' ];
$readmission_year = $row[ 'readmission_year' ];
$readmission_semester = $row[ 'readmission_semester' ];
$final_year_student = $row[ 'final_year_student' ];
$mobile_no = $row[ 'mobile_no' ];
$email = $row[ 'email' ];
$address = $row[ 'address' ];
?>
                            <div class='row'>
                                <div class='col-md-4 inlinediv'>
                                    <label>Register No:</label>
                                    <div><b><?php echo $regno;
?></b>
                                    </div>
                                </div>
                                <div class='col-md-4 inlinediv'>
                                    <label>Student Name:</label>
                                    <div><b><?php echo $row[ 'name' ];
?></b>
                                    </div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>DOB:</label>
                                    <div><b><?php  echo $row[ 'dob' ];
?></b></div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>Mobile No:</label>
                                    <div><input class='form-control' name='mobile' type='text'
                                            value="<?php echo $row[ 'mobile_no' ] ?>" required>
                                    </div>
                                </div>

                                <div class='col-md-4 inlinediv'>
                                    <label>Email ID:</label>
                                    <div><input class='form-control' name='email' type='email'
                                            value="<?php echo $row[ 'email' ] ?>" required>
                                    </div>
                                </div>
       <div class='col-md-4 inlinediv'>
                                    
                                    <div><b>.</div>

                                    </b>

                               
        			</div>
                                <div class='col-md-6'>
                                    <br>
                                    <p style='font-size:12px;'>( Note: If the Mobile No. / Email Id shown is Incorrect,
                                        Update the correct details. All your future communications
                                        will be sent to it. )</p>
                                </div>
                                <div class='col-md-12 inlinediv'>
                                    <label>Course Name:</label>
                                    <div><b><?php echo $row[ 'course' ];
?>
                                        </b>
                                    </div>
                                </div>
                                <div class='col-md-12 inlinediv'>
                                    <label>
                                        Address:
                                    </label>
                                    <div><textarea class='form-control' name='address'><?php echo $address;
?></textarea>
                                    </div>
                                </div>

                                <div class='col-md-6 inlinediv'>
                                    <label>Aadhaar No:</label>
                                    <div><input class='form-control' type='text' name='adhaar_no'
                                            value="<?php echo $row[ 'adhaar_no' ] ?>" required>
                                    </div>
                                </div>
                                <div class='col-md-6 inlinediv'>
                                    <label>Blind:</label>
                                    <div>
                                        <select class='form-control' type='text' name='blind' id='blind'>
                                            <option value='Y' <?php if ( $row[ 'blind' ] === 'Y' ) echo 'selected' ?>>
                                                YES
                                            </option>
                                            <option value='N'
                                                <?php if ( $row[ 'blind' ] === 'N' || $row[ 'blind' ] === '' ) echo 'selected' ?>>
                                                NO
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class='col-md-4 inlinediv'>
                                    <label>Readmission:
                                    </label>
                                    <div>
                                        <select class='form-control' type='text' name='readmission' id='readmission'
                                            onchange='myFunction()'>
                                            <option value='Y'
                                                <?php if ( $row[ 'readmission' ] === 'Y' ) echo 'selected' ?>>
                                                YES
                                            </option>
                                            <option value='N'
                                                <?php if ( $row[ 'readmission' ] === 'N' || $row[ 'readmission' ] === '' ) echo 'selected' ?>>
                                                NO
                                            </option>
                                        </select>
                                    </div>

                                </div>
                                <div class='col-md-12 inlinediv'></div>

                                <div class='col-md-6 inlinediv ' id='readmissiondata1'>
                                    <label>Readmission Year:
                                    </label>
                                    <div>
                                        <input type='text' value="<?php echo $readmission_year; ?>"
                                            name='readmission_year' class='form-control' <?php if ( $row[ 'readmission' ] === 'Y' ) echo 'required';
?>>
                                    </div>
                                </div>
                                <div class='col-md-6 inlinediv' id='readmissiondata2'>
                                    <label>Semester to which Re-admitted:
                                    </label>
                                    <div>
                                        <input type='text' value="<?php echo $readmission_semester; ?>"
                                            name='readmission_semester' class='form-control' <?php if ( $row[ 'readmission' ] === 'Y' ) echo 'required';
?>>
                                    </div>
                                </div>

                            </div><input type='hidden' id='aadhaarphoto' value=" <?php if ( isset( $adhaar_url ) ) {
        echo $adhaar_url;
    }
    ?>" name='aadhaarphoto'>
                            <input type='hidden' id='profilephoto' value="<?php if ( isset( $photo_url ) ) {
        echo $photo_url;
    }
    ?>" name='profilephoto'>
                            <br> <br> <input type='submit' class='btn btn-primary' value='Update'>
                        </form>
                    </div>
                    <div class='col-md-3' class='imgContainer'>

                        <?php if ( $photo_url !== '' && $photo_url !== NULL ) {
    ?><p><b>Photo:</b><br> <img src="<?php echo $photo_url;
    ?>" width='100'></p><?php }
    ?>
                        <div>Upload your Recent passport size photo:</div>
                        <form name='profileupload' onsubmit='return false' method='post' enctype='multipart/form-data'>

                            <input type='hidden' name='regno' value=<?php echo $regno;
    ?>>
                            <input type='file' onchange='upload_check()' name='fileToUpload' id='fileToUpload'
                                class='form-control-file' accept='image/*'>
                            <div id='menuerror'>
                            </div>
                            <br>
                            <input id='profileuploadsubmit' class='btn btn-primary mb-2' type='submit'
                                value='Upload Image' name='submit'>
                        </form>

                        <br>

                        <?php if ( $adhaar_url !== '' && $adhaar_url !== NULL ) {
        ?><p><b>Aadhaar :</b><br> <img src="<?php echo $adhaar_url;
    ?>" width='100'> </p><?php }
        ?>
                        <div>Upload Aadhar Document:</div>
                        <div>
                            <form name='aadhaarupload' onsubmit='return false' method='post'
                                enctype='multipart/form-data' >
                                <input type='hidden' name='regno' value=<?php echo $regno;
        ?>>
                                <input type='file' onchange='upload_adhaar_check()' class='form-control-file'
                                    name='aadhaarToUpload' id='aadhaarToUpload' accept='image/*'>
                                <div id='aadhaarerror'>
                                </div>
                                <br>
                                <input id='aadhaarsubmit' class='btn btn-primary mb-2' type='submit'
                                    value='Upload Aadhaar' name='submit'>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
            <?php $ordersql = "SELECT * FROM `student_order` WHERE `register_no`='".$regno."' and `order_status`='Success'";
        $orderresult = $conn->query( $ordersql );

        if ( $orderresult->num_rows > 0 ) {
            // output data of each row

            ?>
            <div class='col-md-12 color-1'>

                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <table class='table'>
                            <tr>
                                <th>Payment ID </th>

                                <th>
                                    Time & Date </th>
                                <th>Receipt </th>
                            </tr>
                            <?php  while( $orderrow = $orderresult->fetch_assoc() ) {
                ?>
                            <tr>
                                <td><?php echo $orderrow[ 'id' ];
                ?></td>
                                <td><?php echo $orderrow[ 'payment_time' ];
                ?></td>
                                <td><a target='_blank' href="viewreceipt.php?order_id=<?php echo $orderrow[ 'id' ];
                ?>">Download</td>
                            </tr>

                            <?php  }
                ?>
                        </table>
                    </div>
                </div>
            </div>
            <?php

            } else {
                if ( ( $mobile_no !== '' && $mobile_no !== NULL )   && ( $email !== '' && $email !== NULL ) && ( $adhaar_no !== '' && $adhaar_no !== NULL ) && ( $adhaar_url !== '' && $adhaar_url !== NULL ) && ( $photo_url !== '' && $photo_url !== NULL ) ) {
                    ?>
            <div class='col-md-12 color-1'>
                <form action='payment.php' id='payment' method='post'>
                    <div class='box-layout box-shadow row'>

                        <div class='col-md-7'>
                            <h4> Subject Particulars</h4>

                            <table class='table'>
                                <tr>
                                    <th colspan='5'>
                                        <p>Current Semester Subjects <span style='font-size:12px;'>( Compulsory
                                                Registration )</span>
                                        </p>

                                    </th>

                                </tr>
                                <tr>

                                    <th>S No</th>
                                    <th>Semester</th>
                                    <th>Optional</th>
                                    <th>Subject Code</th>
                                    <th>Subject Name</th>
                                    <th>Select</th>

                                </tr>

                                
                          <?php

$sql = "SELECT * FROM `subject_list` where `register_no`='$regno'";
$result = $conn->query( $sql );
$CT = 0;
 while ( $row = $result->fetch_assoc()){
$sem = $row[ 'current_semester' ];
}

                    $subjectssql = "SELECT * FROM `subject_list` WHERE `register_no` = '$regno' and `semester` = '$sem'  ";
                    $subjectsresult = $conn->query( $subjectssql );
                    $currentsubjects = '';
                    $i = 1;
                    
                    while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
                        $currentsubjects .= $subjectsrow[ 'semester' ].',';
                        ?> <tr>
                                    <td> <?php echo $i;
                        ?></td>

                                    <td> <?php echo $subjectsrow[ 'semester' ];
                        ?></td>
                                    <td> <?php echo $subjectsrow[ 'optional_subjects' ];
                        ?></td>
                                    <td> <?php echo $subjectsrow[ 'subject_code' ];
                        ?></td>

                                    <td> <?php echo $subjectsrow[ 'subject_name' ];
                        ?></td>
                                    <td>
                                        <input type='checkbox' id='<?php echo $subjectsrow[ 'subject_code' ]; ?>'
                                            name='current_sem[]' title='<?php echo $subjectsrow[ 'subject_code' ]; ?>'
                                            value='<?php echo $subjectsrow[ 'subject_code' ]; ?>' amount='200' <?php if ( $subjectsrow[ 'optional_subjects' ] == '' ) {
                            echo 'checked' ;
                        }
                        ?> <?php if ( $subjectsrow[ 'optional_subjects' ] == '' ) {
                            echo "onclick='return false'";
                        }
                        ?> onchange='myFunctionInternal()'>
                                    </td>
                                </tr>
                                <?php  $i++;


                    }

                    ?>
                            </table>
                            <div class='subjects'>

                                <table class='table'>
                                    <tr>
                                        <th colspan='5'>
                                            <p>Arrear Semester Subjects<br> <span style='font-size:12px;'>(
                                                    Internal &
                                                    External Arrear papers are shown here, Tick the relevant
                                                    check box,
                                                    for enrolling )</span>
                                            </p>
                                        </th>

                                    </tr>
                                    <tr>
                                        <th>S No</th>
                                        <th>Semester</th>
                                        <th>Subject Code</th>
                                        <th>Subject Name</th>
                                        <th>Internal</th>
                                        <th>External</th>
                                    </tr>
                                    <?php
                        
 $subjectssql = "SELECT * FROM `subject_list` WHERE `register_no` = '$regno' and `semester` != '$sem' ";
                        $subjectsresult = $conn->query( $subjectssql );
                        $i = 1;
$CT =0;
                        while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
                            ?>
                                    <tr>
                                        <td> <?php echo $i;
                            ?></td>

                                        <td> <?php echo $subjectsrow[ 'semester' ];
                            ?></td>
                                        <td> <?php echo $subjectsrow[ 'subject_code' ];
                            ?></td>

                                        <td> <?php echo $subjectsrow[ 'subject_name' ];
                            ?></td>
                                        <td>
                                            <?php if ( $subjectsrow[ 'internal_status' ] !== 'T' ) {
                                ?> <input type='checkbox' id='<?php echo $subjectsrow[ 'subject_code' ]; ?>'
                                                name='other_sem_internal[]'
                                                title='<?php echo $subjectsrow[ 'subject_code' ]; ?>' value='<?php echo $subjectsrow[ 'subject_code' ];
                        ?>' amount='200' onclick='myFunctionInternal()'> <?php }
                                ?>
                                        </td>
                                        <td>
                                            <?php if ( $subjectsrow[ 'external_status' ] !== 'T' ) {
                                    ?> <input type='checkbox' id='<?php echo $subjectsrow[ 'subject_code' ]; ?>'
                                                name='other_sem_external[]'
                                                title='<?php echo $subjectsrow[ 'subject_code' ]; ?>' value='<?php echo $subjectsrow[ 'subject_code' ];
                        ?>' amount='200' onclick='myFunctionInternal()'> <?php }
                                    ?>
                                        </td>
                                    </tr>
                                    <?php $i++;
                                     $CT=$CT+200;
                                }
                                ?>
                                </table>
                            </div>
                            <?php if ( ( isset( $readmission ) && $readmission === 'Y' ) || $student_status !== 'CURRENT' ) {
                                    ?>
                            <p style='font-size:14px;'>If your subject code is not shown above, Enter the
                                Subject Code
                                followed by Comma ( , ) :
                            </p>
                            <input type='text' name='othersubjects' id='othersubjects' class='form-control'
                                placeholder='Other Subject' onChange='myFunctionInternal()'><br>
                            <?php }
                                    ?>

                        </div>
                        <div class='col-md-5'>
                            <h2>EXAM FEE STRUCTURE</h2>
                            <br> <?php  $subjectssql = "SELECT  count( * ) as totalcount FROM `subject_list` WHERE `register_no` = '$regno' and `semester` = '$current_sem' and optional_subjects='' ";
                                    $subjectsresult = $conn->query( $subjectssql );
                                    $subjectsrow = $subjectsresult->fetch_assoc();
                                    $semprice = $subjectsrow[ 'totalcount' ]* 200 ;

                                    ?>
                            <p>Current Semster Exam Fee:<span id='semamount'><?php echo $semprice;
                                    ?></span></p>
                            <p>Other Semster Exam Fee:<span id='examamount'></span></p>

                            <div>
                                <div class='options'>
                                    <input type='checkbox' id='application_fee' name='Application fee'
                                        title='Application fee' value='25' amount='25' checked onclick='return false'>
                                    Application fee -
                                    Rs. 25<br>
                                    <input type='checkbox' id='mark_statement' title='Statement of Marks'
                                        name='Statement of Marks' value='50' amount='50' checked onclick='return false'>
                                    Statement of
                                    Marks - Rs. 50<br><?php if ( $final_year_student === 'Y' || $student_status !== 'CURRENT' ) {
                                        ?>
                                    <input type='checkbox' id='provisional' name='Provisional Certificate'
                                        title='Provisional Certificate' value='175' amount='175'
                                        onChange='myFunctionInternal()'> Provisional
                                    Certificate - Rs. 175<br>

                                    <input type='checkbox' id='csm' name='Consolidated Statement of Marks'
                                        title='Consolidated Statement of Marks' value='525' amount='525'
                                        onChange='myFunctionInternal()'> Consolidated
                                    Statement of Marks - Rs. 525<br>
                                    <input type='checkbox' id='convocation' name='Convocation Fees'
                                        title='Convocation Fees' value='425' amount='425'
                                        onChange='myFunctionInternal()'>
                                    Convocation Fees -
                                    425<br> <?php }
                                        ?>
                                    <?php $penaltydate = '30-12-2022' ;
                                        $currentdate = date( 'd-m-Y' );
                                        if ( $currentdate>$penaltydate ) {
                                            ?>
                                    <input type='checkbox' id='penalty' name='penalty' title='Penalty' value='100'
                                        amount='100' onChange='myFunctionInternal()' checked onclick='return false'>
                                    Penalty Fee - Rs. 100<br>

                                    <?php }
                                            ?>
                                </div>
                                <br>
                              
                                Total: Rs. <b id='seats-total'><?php echo $semprice= 25 + 50;
                                                                
                                            ?> </b>

                            </div>
                        </div>
                        <div class='col-md-6'></div>
                        <div class='col-md-6 text-right'> <br>


                          <input type="submit" value="Pay Now" >
                                                  

                        </div>
                </form>
            </div>
        </div>
        <?php } else {
                                                ?>
        <?php }
                                            }
                                            ?>

    </div>
    </div>
    <!--- Count Down End -->

</body>
<script src='https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js' crossorigin='anonymous'
    referrerpolicy='no-referrer'></script>
<script>
var element = document.getElementById('element-to-print');
var opt = {
    margin: 1,
    filename: 'myfile.pdf',
    image: {
        type: 'jpeg',
        quality: 0.98
    },
    html2canvas: {
        scale: 2
    },
    jsPDF: {
        unit: 'in',
        format: 'letter',
        orientation: 'portrait'
    }
};

// New Promise-based usage:
html2pdf().set(opt).from(element).save();

// Old monolithic-style usage:
html2pdf(element, opt);
</script>
<script src='https://code.jquery.com/jquery-3.6.0.min.js' crossorigin='anonymous'></script>
<script>
$('#profileuploadsubmit').hide();
$('#aadhaarsubmit').hide()

function upload_check() {
    var upl = document.getElementById('fileToUpload');
    var max = '200000';

    if (upl.files[0].size > max) {
        $('#menuerror').html('File should be less than 200kb');
        upl.value = '';
        $('#profileuploadsubmit').hide();
    } else {
        $('#menuerror').html('');
        $('#profileuploadsubmit').show();
    }
};

function upload_adhaar_check() {
    var upla = document.getElementById('aadhaarToUpload');
    var max = '200000';

    if (upla.files[0].size > max) {
        $('#aadhaarerror').html('File should be less than 200kb');
        upla.value = '';
        $('#aadhaarsubmit').hide();
    } else {
        $('#aadhaarerror').html('');
        $('#aadhaarsubmit').show();
    }
};
</script>
<script>
$("form[ name = 'profileupload' ]").submit(function(e) {
    var formData = new FormData($(this)[0]);
    //alert( 'work' );
    $.ajax({
        url: 'upload.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function(msg) {
            $('#menuerror').html('<img src = ' + msg + '>');
            $('#profilephoto').val(msg);
        },
        cache: false,
        contentType: false,
        processData: false
    });

    e.preventDefault();
});

$("form[ name = 'aadhaarupload' ]").submit(function(e) {
    var formData = new FormData($(this)[0]);
    //alert( 'work' );
    $.ajax({
        url: 'upload.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function(msg) {
            $('#aadhaarerror').html('<img src = ' + msg + '>');
            $('#aadhaarphoto').val(msg);
        },
        cache: false,
        contentType: false,
        processData: false
    });

    e.preventDefault();
});
</script>
<script>
function myFunctionInternal() {

    var seatsTotal = document.getElementById('seats-total');
    var examamount = document.getElementById('examamount');
    var semamount = document.getElementById('semamount');
    var othersubjectslen = 0;
    var othersubjectArray = 0;

    var provisional = 0;
    if ($('#provisional').is(':checked')) {
        provisional = 175;
    } else {
        provisional = 0;
    }
    var csm = 0;
    if ($('#csm').is(':checked')) {
        csm = 525;
    } else {
        csm = 0;
    }
    var convocation = 0;
    if ($('#convocation').is(':checked')) {
        convocation = 425;
    } else {
        convocation = 0;
    }
    var penalty = 0;
    if ($('#penalty').is(':checked')) {
        penalty = 100;
    } else {
        penalty = 0;
    }

    var othersubjects = $('#othersubjects').val();
    if (othersubjects) {
        var othersubjects = othersubjects.slice(0, -1);
        var othersubjectArray = othersubjects.split(',');
        var othersubjectslen = othersubjectArray.length;
    }
    var other_sem_internal = new Array();
    $.each($("input[name='other_sem_internal[]']:checked"), function() {
        other_sem_internal.push($(this).val());
    });
    var other_sem_external = new Array();
    $.each($("input[name='other_sem_external[]']:checked"), function() {
        other_sem_external.push($(this).val());

    });
    other_sem = [...other_sem_external]

    let uniqueother_sem = other_sem.filter((c, index) => {
        return other_sem.indexOf(c) === index;
    });

    var currentlength = 0;
    var currentlength = $("[name='current_sem[]']:checked").length;
    var arrearsub=other_sem.length;

    if ($('#blind').val() !== 'Y') {
        semamount.innerHTML = currentlength * 200 ;
        examamount.innerHTML = (currentlength * 200) + (othersubjectslen * 200)+ other_sem_internal.length*400 + other_sem_external.length*200;
        seatsTotal.innerHTML = (currentlength * 200) + 25 + 50 + other_sem_internal.length*400 + other_sem_external.length*200 + (othersubjectslen *
                200) + 
            provisional + csm + convocation + penalty;
    } else {
        semamount.innerHTML = '0';
        examamount.innerHTML = '0';
        seatsTotal.innerHTML = 25 + 50 + provisional + csm + convocation + penalty;
    }

}
</script>
<script>
var x = document.getElementById('readmission').value;
var readmissiondataone = document.getElementById('readmissiondata1');
var readmissiondatatwo = document.getElementById('readmissiondata2');
if (x === 'Y') {
    readmissiondataone.style.display = 'block';
    readmissiondatatwo.style.display = 'block';
} else {
    readmissiondataone.style.display = 'none';
    readmissiondatatwo.style.display = 'none';
}

function myFunction() {
    var x = document.getElementById('readmission').value;
    var readmissiondataone = document.getElementById('readmissiondata1');
    var readmissiondatatwo = document.getElementById('readmissiondata2');
    if (x === 'Y') {
        readmissiondataone.style.display = 'block';
        readmissiondatatwo.style.display = 'block';
    } else {
        readmissiondataone.style.display = 'none';
        readmissiondatatwo.style.display = 'none';
    }
}
</script>

<?php include( 'include/footer.php' );