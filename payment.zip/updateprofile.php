<?php
include( 'connection.php' );

session_start();
$regno = $_SESSION[ 'regno' ];
if ( !$regno ) {
    header( 'location:logout.php' );
}
$mobile_no = $_POST[ 'mobile' ];
$email = $_POST[ 'email' ];
$adhaar_no = $_POST[ 'adhaar_no' ];
$adhaar_url = $_POST[ 'aadhaarphoto' ];
$photo_url = $_POST[ 'profilephoto' ];
$blind = $_POST[ 'blind' ];
$clinical = $_POST[ 'clinical' ];
$readmission = $_POST[ 'readmission' ];
$academic_year = $_POST[ 'academic_year' ];
$college_name = $_POST[ 'college_name' ];
$address = $_POST[ 'address' ];
$readmission_year = $_POST[ 'readmission_year' ];
$readmission_semester = $_POST[ 'readmission_semester' ];
$sql = "UPDATE `students` SET `mobile_no`='".$mobile_no."',`email`='".$email."',`college_name`='".$college_name."', `address`='".$address."', `blind`='".$blind."',`clinical`='".$clinical."',`adhaar_no`='".$adhaar_no."',`adhaar_url`='".$adhaar_url."',`photo_url`='".$photo_url."',`readmission`='".$readmission."', `readmission_year`='".$readmission_year."',`readmission_semester`='".$readmission_semester."', `academic_year`='".$academic_year."' WHERE `register_no`='".$regno."'";
$result = $conn->query( $sql );
if ( $result )
 {

    header( 'location:index.php' );
}
?>