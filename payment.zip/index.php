<?php include( 'include/header.php' );
require( 'mpdf/mpdf.php' );
?>
<style>

</style>

<body>
    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
              
            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'></div>
        <div class='col-md-12 text-right'><a href='logout.php'>Logout</a></div>
    </div>
    <div class='container '>
        <div class='row'>
            <div class='col-md-12 color-1  '>
                <div class='box-layout box-shadow row'>

                    <div class='col-md-12'>

                        <?php
$sql = "SELECT * FROM `students` where `register_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();

?>
                        <?php $nominalsql = "SELECT * FROM `nominal_roll` WHERE `register_no`='".$regno."'";
$nominalresult = $conn->query( $nominalsql );

if ( $nominalresult->num_rows > 0 ) {
    ?>

                        <?php  $subjectrowdetail = '';
    while( $nominalrow = $nominalresult->fetch_assoc() ) {
        $hallticket =  $nominalrow[ 'hallticket' ];
        $course_name =  $nominalrow[ 'course_name' ];
        $name =  $nominalrow[ 'name' ];
        $dob =   $nominalrow[ 'dob' ];
        $register_no = $nominalrow[ 'register_no' ];
        $course_name =  $nominalrow[ 'course_name' ];
        $college_name = $nominalrow[ 'centre' ].' - '.$nominalrow[ 'centre_name' ];
        $subjectrowdetail .= '<tr>
                                        <td style="border: 1px solid #303030 !important;"> '.$nominalrow[ 'subject_code' ].'
                                        </td>
                                        <td style="border: 1px solid #303030 !important;">'.$nominalrow[ 'subject_name' ].'
                                        </td>

                                        <td style="border: 1px solid #303030 !important;">'.$nominalrow[ 'exam_date' ].'
                                        </td>
                                        <td style="border: 1px solid #303030 !important;">'.$nominalrow[ 'exam_time' ].'
                                        </td>

                                    </tr>';
        ?>

                        <?php }

        ?><?php $html = '
	<table width="650" border="0" align="center">
  <tbody>
    <tr>
      <td><img src="logo.jpg" width="100%"></td>
    </tr>
   <tr>
   <td align="center"> 
                        <h3> HONOURS DEGREE COURSES ,DECEMBER 2022 EXAMINATIONS</h3>
                        <h5>EXAMINATION APPLICATION FORM</h5>
   </td>
   </tr>
	  <tr>
      <td>
		  <table width="100%" border="0" padding="5" style="vertical-align:top;" >
  <tbody>
  <br>
    <tr>
      <td width="33%" style="padding:5px; vertical-align: top;">Register No:&nbsp; <b>'.$register_no.'</b></td>
<td width="33%" style="padding:5px; vertical-align: top;">Name:&nbsp; <b>'.$name.'</b> </td>
<td width="33%" style="padding:5px; vertical-align: top;">DOB:&nbsp; <b>'.$dob.'</b></td>
</tr>
<tr>
    <td style="padding:5px; vertical-align: top;">Course:&nbsp; <br><b>'.$course_name.'</b> </td> <td style="padding:5px; vertical-align: top;">Exam Centre:&nbsp; <br><b>'.$college_name.'</b> </td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
    <td>&nbsp;
    </td>
</tr>
<tr>
    <td>
        <table width="100%" border="0" cellspacing="5" cellpadding="5" style="padding:5px; border:1px !important;;">
            <tbody>
                <tr>
                    <td style="border: 1px solid #303030 !important;" colspan="4"><strong>Subjects Enrolled</strong></td>

                </tr>
                <tr>
                    <td style="border: 1px solid #303030 !important;"><strong>Subject Code&nbsp;</strong></td>
                    <td style="border: 1px solid #303030 !important;"><strong>Subject Name</strong></td>
                    <td width="20%"><strong>Exam Date</strong></td>
<td style="border: 1px solid #303030 !important;"><strong>Exam Time</strong></td>
                </tr>
               '. $subjectrowdetail .'

            </tbody>
        </table>
    </td>
</tr>
</tr>
</tbody>
</table>';

        ?>

                        <div id='element-to-print'><?php echo $html;
        error_reporting( 0 );
        $mpdf = new mPDF( $html );
        $mpdf->WriteHTML( $html );
        $name = $register_no;
        $mpdf->Output( 'enroll/'.$name.'.pdf', 'F' );
        $file = 'enroll/'.$name.'.pdf';
        ?></div>
                        <br><br><br>
                        <a href='https://tndalucoe.in/examappl_dec/hallticket/<?php echo $hallticket; ?>' class='downloadbutton'
                            target='_blank'>Download Hall
                            Ticket</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href='<?php echo $file; ?>' target='_blank' class='downloadbutton'>Print Enroll</a>

                        <?php

    } else {
        echo 'No Record Found';
        ;
    }
    ?>

                    </div>
                </div>
            </div>
        </div>
        <a href=''>
            <!--- Count Down End -->

</body>
<script src='https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js' crossorigin='anonymous'
    referrerpolicy='no-referrer'></script>
<script>
var element = document.getElementById('element-to-print');
var opt = {
    margin: 0,
    filename: '<?php echo $register_no; ?>.pdf',
    image: {
        type: 'jpeg',
        quality: 0.98
    },

    html2canvas: {
        scale: 1
    },
    jsPDF: {
        unit: 'in',
        format: 'letter',
        orientation: 'portrait'
    }
};

// New Promise-based usage:

function myFunction() {
    html2pdf().set(opt).from(element).save();
}
// Old monolithic-style usage:
//html2pdf( element, opt );
</script>

<script>

</script>

<?php include( 'include/footer.php' );