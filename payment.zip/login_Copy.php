<html lang="en-US">
<?php session_start();?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DECEMBER 2022 EXAM APPLICATION FORM <br>HONOURS DEGREE COURSES | The Tamilnadu Dr. Ambedkar Law University
    </title>
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" />
    <link type="text/css" href="css/main.css" rel="stylesheet" />
    <link type="text/css" href="css/device.css" rel="stylesheet" />
    <link type="text/css" href="css/mobile.css" rel="stylesheet" />
    <link rel="shortcut icon" href="https://tndalu.ac.in/img/tl.png">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
    .refresh-captcha {
        font-size: 20px;
        padding: 10px;
        color: #007bff;
    }

    #menuerror {
        color: red;
    }
    </style>
</head>

<body>

    <div class="container" style="background:#f7fcf8;">
        <div class="row">
            <div class="col-md-12">
                <div class="text-center"><br><br><img src="logo.jpg" class="img-responsive" /><br><br>
                    <h2 style="color:green;">HONOURS DEGREE COURSES ,DECEMBER 2022 EXAMINATIONS </h2>
                </div>
            </div>
            <div class="col-md-12">
                <div class="login-form">
                    <form name='loginRequest' onsubmit='return false' method='post' autocomplete="off">
                        <h4 class="text-center">EXAMINATION APPLICATION FORM</h4>
                        <div class="form-group">
                            <label>Register No</label>
                            <input type="text" class="form-control" name="regno" id="regno" placeholder="Register No"
                                required>
                        </div>
                        <div class="form-group"> <label>Password</label>
                            <input type="password" class="form-control" name="password" id="password"
                                placeholder="Password" required>
                        </div>
                        <div class="g-recaptcha" data-sitekey="6LdQ-QMgAAAAAE081epTU-ZgVD4rmM7PKMOjtCuQ"></div>

                       <!-- <input id='loginsubmit' type='submit' value='Login' class='btn btn-primary' name='submit'> -->



		
     
                        <p id="menuerror">APPLICATION CLOSED</p> 

                    </form>
                    <br>

                </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-8 alert alert-success mt-5" role="alert">
                <h4 class="alert-heading">Password Hint</h4>
                <p> First 4 letters of your first name and date of birth in DDMMYYYY is the password.
                    <br>E.g. <br>1: - RAMESH KUMAR S and birth year is 22-04-1996 Then the Password will be RAME22041996
                    <br>2: - K MURUGAN and birth year is 11-10-1985 Then the Password will be KMUR11101985
                    <br>3: - ABI S and birth year is 18-08-2001 Then the Password will be ABIS18082001
                </p>
                <hr>
                <p class="mb-0">For Queries related to Payment, Contact : 8015102657 / 7200410859 Working Hours: 10.00
                    am to 6.00 pm</p>
            </div>
        </div>
    </div>

</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$("form[name='loginRequest']").submit(function(e) {
    var formData = new FormData($(this)[0]);
   
    $.ajax({
        url: 'loginsubmit.php',
        type: 'POST',
        data: formData,
        async: false,
        success: function(msg) {
            if (msg === 'Success') {
             window.location = 'https://tndalucoe.in/examappl_dec';
                
            } else {
                $("#regno").val('');
                $("#password").val('');
                grecaptcha.reset();
                $('#menuerror').html(msg);
            }
        },
        cache: false,
        contentType: false,
        processData: false
    });

    e.preventDefault();
});
</script>
<script src="js/bootstrap.js"></script>

</html>