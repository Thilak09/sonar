<html>
<?php include("connection.php"); 
session_start(); 
 ?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXAMINATION APPLICATION FORM | The Tamilnadu Dr. Ambedkar Law University</title>
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" />
    <link type="text/css" href="css/main.css" rel="stylesheet" />
    <link type="text/css" href="css/device.css" rel="stylesheet" />
    <link type="text/css" href="css/mobile.css" rel="stylesheet" />
    <link rel="shortcut icon" href="https://tndalu.ac.in/img/tl.png">
    <link type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css"
        rel="stylesheet" />
</head>
<?php
require( 'mpdf/mpdf.php' );
$order_id = $_GET[ 'order_id' ];
$Application_fee = 0;
$Statement_of_Marks = 0;
$Provisional_Certificate = 0;
$Consolidated_Statement_of_Marks = 0;
$Convocation_Fees =  0;
$subject_code =  0;
$subjectcount =  0;

$ordersql = "SELECT * FROM `student_order` WHERE `id`='".$order_id."' and `order_status`='Success'";
$orderresult = $conn->query( $ordersql );
$orderrow = $orderresult->fetch_assoc();
$regno = $orderrow[ 'register_no' ];
$Application_fee = $orderrow[ 'application_fee' ];
$Statement_of_Marks = $orderrow[ 'statement_of_marks' ];
$Provisional_Certificate = $orderrow[ 'provisional_certificate' ];
$Consolidated_Statement_of_Marks = $orderrow[ 'consolidated_statement_of_mark' ];
$Convocation_Fees = $orderrow[ 'convocation_fees' ];
$total_fee = $orderrow[ 'total_fee' ];
$subjects = $orderrow[ 'subjects' ];
$payment_time = $orderrow[ 'payment_time' ];
$exam_fee = $orderrow[ 'exam_fee' ];
$no_ofsubjects = $orderrow[ 'no_ofsubjects' ];
?>

<body onload='overlay();'>

    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg'
                        class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'>
            <div class='col-md-12 color-1'>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <h2>Exam Application Review</h2>
                    </div>
                    <div class='col-md-12'>

                        <?php
$sql = "SELECT * FROM `students` where `register_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();
$current_sem = $row[ 'current_semester' ];
$dob = $row[ 'dob' ];
$name = $row[ 'name' ];
$aadhar_url = $row[ 'aadhar_url' ];
$photo_url = $row[ 'photo_url' ];
$readmission = $row[ 'readmission' ];
$readmission_year = $row[ 'readmission_year' ];
$readmission_semester = $row[ 'readmission_semester' ];
$mobile_no = $row[ 'mobile_no' ];
$email = $row[ 'email' ];
$college_name = $row[ 'college_name' ];
$course = $row[ 'course' ];
$adhaar_no = $row[ 'adhaar_no' ];
$course = $row[ 'course' ];
$blind = $row[ 'blind' ];
?>
                        <div class='row'>
                            <div class='col-md-10'>
                                <div class='row'>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Register No:</div>
                                        <div><b><?php echo $regno;
?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Student Name:</label>
                                        <div><b><?php echo $row[ 'name' ];
?></b>
                                        </div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <div>DOB:</div>
                                        <div><b><?php  echo $row[ 'dob' ];
?></b></div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <div>Mobile No:</div>
                                        <div><b><?php echo $row[ 'mobile_no' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Email ID:</div>
                                        <div><b><?php echo $row[ 'email' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Exam Centre:</div>
                                        <div><b><?php  echo $row[ 'centre_code' ];
?> - <?php  echo $row[ 'college_name' ];
?>

                                            </b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Course Name:</div>
                                        <div><b><?php  echo $row[ 'course' ];
?></b>
                                        </div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <div>Aadhaar No:</div>
                                        <div><b><?php echo $row[ 'aadhar_no' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Blind:</div>
                                        <div>
                                            <?php if ( $row[ 'blind' ] === 'Y' ) {
    echo 'YES';
} else {
    echo 'NO';
}
?>
                                        </div>

                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Readmission:</div>
                                        <div>
                                            <?php if ( $row[ 'readmission' ] === 'Y' ) {
    echo 'YES';
} else {
    echo 'NO';
}
?>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Readmission Year:</div>
                                        <div>
                                            <?php echo $row[ 'readmission_year' ] ?>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <div>Re-admitted Semester:</div>
                                        <div>
                                            <?php echo $row[ 'readmission_semester' ] ?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class='col-md-2'><img src='<?php echo $photo_url; ?>' width='150'></div>
                        </div>
                        <br> <br>
                        <h3>Details</h3>
                        <p>No.Subjects Enrolled : <?php echo $no_ofsubjects;
?>

                        <table class='table'>
                            <tr>
                                <th colspan='3'>Current Semester Subjects:</th>
                            </tr>
                            <tr>
                                <th>Subject Code
                                </th>
                                <th>Subject Name
                                </th>
                                <th>Optional Subject
                                </th>
                                <th>Semester
                                </th>
                            </tr>
                            <?php
$subjectssql = "SELECT * FROM `enrolled_subjects` WHERE `order_id`='".$order_id."' and `semester`='$current_sem'";
$subjectsresult = $conn->query( $subjectssql );
$currentrow = '';
while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {

    $currentrow .= '<tr> <td> '.$subjectsrow[ 'subject_code' ].'
                                </td>
                                <td>'.$subjectsrow[ 'subject_name' ].'
                                </td>
                                  <td>'.$subjectsrow[ 'optional_subjects' ].'
                                </td>
                                <td>'.$subjectsrow[ 'semester' ].'
                                </td>
                            </tr>';

}
echo  $currentrow;
?>
                        </table>

                        <table class='table'>
                            <tr>
                                <th colspan='6'>Arrear Semester Subjects:</th>
                            </tr>
                            <tr>
                                <th>Subject Code
                                </th>
                                <th>Subject Name
                                </th>
                                <th>Semester
                                </th>
                                <th>Internal
                                </th>
                                <th>External
                                </th>
                            </tr>
                            <?php
$subjectssql = "SELECT * FROM `enrolled_subjects` WHERE `order_id`='".$order_id."' and `semester`!='$current_sem'";
$subjectsresult = $conn->query( $subjectssql );
$arrearrow = '';
while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
    if ( $subjectsrow[ 'internal_status' ] === 'T' ) {
        $internal_status = '&#10004;';
    } else {
        $internal_status = '';
    }
    if ( $subjectsrow[ 'external_status' ] === 'T' ) {
        $external_status = '&#10004;';
    } else {
        $external_status = '';
    }
    $arrearrow .= '<tr> <td> '.$subjectsrow[ 'subject_code' ].'
                                </td>
                                <td>'.$subjectsrow[ 'subject_name' ].'
                                </td>
                               
                                <td>'.$subjectsrow[ 'semester' ].'
                                </td>
                                   <td>'.$internal_status.'
                                </td>
                                   <td>'.$external_status.'
                                </td>
                            </tr>';

}
echo  $arrearrow;
?>
                        </table>
                        </p>
                        <p>Other Unlisted Subjects : <?php echo $subjects ?>
                        <p>Exam Fee : <?php echo $exam_fee;
?>
                        <p>Application fee : <?php echo $Application_fee;
?></p>
                        <p>Statement of Marks : <?php echo $Statement_of_Marks;
?></p>
                        <p>Provisional Certificate : <?php echo $Provisional_Certificate;
?></p>
                        <p>Consolidated Statement of Marks : <?php echo $Consolidated_Statement_of_Marks;
?></p>
                        <p>Convocation Fees : <?php echo $Convocation_Fees;
?></p>
                        <p>Total Fee : <?php echo $total_fee;
?>
                        <p>Receipt Date & Time : <?php echo $payment_time;
?>
                            <b>
                            </b>
                        </p>

                    </div>

                </div>

            </div>
            <?php
?>

        </div>
    </div>

    <!--- Count Down End -->

</body>
<?php $html = '<html>
<head>
</head>
<body>
	
	<table width="800" border="0" align="center">
  <tbody>
    <tr>
      <td><img src="https://coe.tndalu.ac.in/Images/logo.jpg" width="100%"></td>
    </tr>
	  <tr>
      <td>
		  <table width="100%" border="0" padding="5" style="vertical-align:top;" >
  <tbody>
    <tr>
      <td width="33%" style="padding:5px; vertical-align: top;">Register No:&nbsp; <b>'.$regno.'</b></td>
<td width="33%" style="padding:5px; vertical-align: top;">Name:&nbsp; <b>'.$name.'</b> </td>
<td width="33%" style="padding:5px; vertical-align: top;">DOB:&nbsp; <b>'.$dob.'</b></td>
</tr>
<tr>
    <td style="padding:5px; vertical-align: top;">Semester:&nbsp; <b>'.$current_sem.'</b></td>
    <td style="padding:5px; vertical-align: top;">Course Name:&nbsp; <b>'.$course.'</b></td>
    <td style="padding:5px; vertical-align: top;">Exam Centre:&nbsp; <b>'.$college_name.'</b> </td>

</tr>
<tr>
    <td style="padding:5px; vertical-align: top;">Aadhaar No:&nbsp; <b>'.$aadhar_no.'</b></td>
    <td style="padding:5px; vertical-align: top;">Blind:&nbsp; <b>'.$blind.'</b></td>
    <td style="padding:5px; vertical-align: top;">&nbsp;</td>
</tr>
<tr>
    <td style="padding:5px; vertical-align: top;">Readmission:&nbsp; <b>'.$readmission.'<b> </td>
    <td style="padding:5px; vertical-align: top;">Readmission<br>Year:&nbsp; <b>'.$readmission_year.'</b> </td>
    <td style="padding:5px; vertical-align: top;">Re-admitted<br>
        Semester:&nbsp; <b>'.$readmission_semester.'</b> </td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
    <td>&nbsp;
    </td>
</tr>
<tr>
    <td>
        <table width="100%" border="0" style="padding:10px;">
            <tbody>
                <tr>
                    <td colspan="4"><strong>Current Semester Subjects</strong></td>

                </tr>
                <tr>
                    <td><strong>Subject Code&nbsp;</strong></td>
                    <td><strong>Subject Name</strong></td>
                    <td><strong>Optinal Subject</strong></td>
<td><strong>Semester</strong></td>
                </tr>
               '. $currentrow .'

            </tbody>
        </table>
    </td>
</tr>
</tr>
<tr>
    <td>&nbsp;
    </td>
</tr>
<tr>
    <td>
        <table width="100%"  border="0" style=" padding:10px;"
>
            <tbody>
                <tr>
                    <td colspan="5"><strong>Arrear Semester Subjects</strong></td>

                </tr>
                <tr>
                    <td><strong>Subject Code&nbsp;</strong></td>
                    <td><strong>Subject Name</strong></td>  
                    <td><strong>Semester</strong></td>
                    <td><strong>Internal</strong></td>
                    <td><strong>External</strong></td>
                </tr>
                ' .$arrearrow. '
            </tbody>
        </table>
    </td>
</tr>
<tr>
    <td style="padding: 10px;"><br><br>
        Other Unlisted Subjects : '.$subjects.'<br><br>

        Exam Fee :  '.$exam_fee.'<br><br>

Application fee : '.$Application_fee.'<br><br>

Statement of Marks : '.$Statement_of_Marks.'<br><br>

Provisional Certificate : '.$Provisional_Certificate.'<br><br>

Consolidated Statement of Marks : '.$Consolidated_Statement_of_Marks.'<br><br>

Convocation Fees : '.$Convocation_Fees.'<br><br>

Total Fee : '.$total_fee.'<br><br>

Receipt Date & Time : '.$payment_time.'<br><br><br></td>
</tr>
<tr>
    <td style="background-color: antiquewhite; padding: 10px; text-align: center">2022 &copy; TNDALU</td>
</tr>
</tbody>
</table>

</body>

</html>';

error_reporting( 0 );
$mpdf = new mPDF( $html );
$mpdf->WriteHTML( $html );
$name = $order_id;
$mpdf->Output( 'pdf/'.$name.'.pdf', 'F' );
$file = 'pdf/'.$name.'.pdf';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
require 'Mail/PHPMailer.php';
require 'Mail/SMTP.php';
require 'Mail/Exception.php';

//Load Composer's autoloader
//require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer();


    $mail->isSMTP();

//Enable SMTP debugging

$mail->SMTPDebug =false;

//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';

//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';

//Set the hostname of the mail server
$mail->Host = 'email-smtp.ap-south-1.amazonaws.com';

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
// I tried PORT 25, 465 too
$mail->Port = 587;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = 'AKIA4CI7IAPRW3OOFJMH';

//Password to use for SMTP authentication
$mail->Password = 'BHpBATy9qrpaTz6dC5MA69utrVaqO1emcZYkZP3tkX3y';

//Set who the message is to be sent from
$mail->setFrom('tndaluweb@gmail.com', 'TNDALU');

//Set who the message is to be sent to
$mail->addAddress($email, 'receiver');

//Set the subject line
$mail->Subject = 'Payment Confirmation - ALL HONOURS DEGREE COURSE EXAMINATIONS, JUNE 2022';


$mail->Body = $html;
//Replace the plain text body with one created manually
$mail->AltBody = $html;
$mail->addAttachment($file);
//send the message, check for errors
//$mail->send();
?>
<?php include( 'include/footer.php' );
?>