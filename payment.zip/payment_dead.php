<?php include( 'include/header.php' );
$CCA_MERCHANT_ID = 750606;

$Application_fee = 0;
$Statement_of_Marks = 0;
$Provisional_Certificate = 0;
$Consolidated_Statement_of_Marks = 0;
$Convocation_Fees =  0;
$subject_code =  0;
$subjectcount =  0;
$current_semsubjects = [];
$current_semsubjects_count = 0;
$examfee = 0;
$other_sem_external = [];
$other_sem_externalcount = 0;
$other_sem_internal = [];
$other_sem_internalcount = 0;
$othersubjectsarray = [];
$othersubjects_count = 0;
$othersubjects = '';
$penaltydate = '30-05-2023' ;
$currentdate = date( 'd-m-Y' );
if ( $currentdate>$penaltydate ) {
    $penalty = 0;
} else {
    $penalty = 0;
}
$penalty = 0;
$tatkal = 1000;
if ( isset( $_POST[ 'current_sem' ] ) )
 {
    $current_semsubjects = $_POST[ 'current_sem' ];
    $current_semsubjects_count = count( $current_semsubjects );
}
if ( isset( $_POST[ 'other_sem_external' ] ) )
 {
    $other_sem_external = $_POST[ 'other_sem_external' ];
    $other_sem_externalcount = count( $other_sem_external );
}
if ( isset( $_POST[ 'othersubjects' ] ) )
 {
    $othersubjects = trim( $_POST[ 'othersubjects' ] );
    if ( $othersubjects !== '' )
 {
        $othersubjectsarray = array_filter( explode( ',', $othersubjects ) );
        $othersubjects_count = count( $othersubjectsarray );
    }

}
if ( isset( $_POST[ 'other_sem_internal' ] ) )
 {
    $other_sem_internal = $_POST[ 'other_sem_internal' ];
    $other_sem_internalcount = count( $other_sem_internal );
}
if ( isset( $_POST[ 'Application_fee' ] ) )
 {
    $Application_fee = $_POST[ 'Application_fee' ];
}
if ( isset( $_POST[ 'penalty' ] ) )
 {
    $penalty = $_POST[ 'penalty' ];
}
if ( isset( $_POST[ 'Statement_of_Marks' ] ) )
 {
    $Statement_of_Marks = $_POST[ 'Statement_of_Marks' ];
}
if ( isset( $_POST[ 'Provisional_Certificate' ] ) )
 {
    $Provisional_Certificate = $_POST[ 'Provisional_Certificate' ];
}
if ( isset( $_POST[ 'Consolidated_Statement_of_Marks' ] ) )
 {
    $Consolidated_Statement_of_Marks = $_POST[ 'Consolidated_Statement_of_Marks' ];
}
if ( isset( $_POST[ 'Convocation_Fees' ] ) )
 {
    $Convocation_Fees = $_POST[ 'Convocation_Fees' ];
}
$other_sem = array_unique( array_merge( $other_sem_external, $other_sem_internal ), SORT_REGULAR );
$other_sem_fee = count( $other_sem );

$subjectcount = $current_semsubjects_count + $other_sem_fee + $othersubjects_count;

?>

<body onload='overlay();'>
    <div class='container-fluid'>
        <header class='container'>
            <div class='row '>
                <div class='col-12 text-center'> <img src='logo.jpg'
                        class='img-mobile' /> </div>

            </div>
            <br><br>
        </header>
    </div>
    <div class='container'>
        <div class='row'>
            <div class='col-md-12 color-1  '>
                <div class='box-layout box-shadow row'>
                    <div class='col-md-12'>
                        <h2>Exam Application Review</h2>
                    </div>
                    <div class='col-md-12'>

                        <?php
$sql = "SELECT * FROM `students` where `register_no`='$regno'";
$result = $conn->query( $sql );
$row = $result->fetch_assoc();
$current_sem = $row[ 'current_semester' ];
$name = $row[ 'name' ];
$adhaar_url = $row[ 'adhaar_url' ];
$photo_url = $row[ 'photo_url' ];
$readmission = $row[ 'readmission' ];
$mobile_no = $row[ 'mobile_no' ];
$email = $row[ 'email' ];
$address = $row[ 'address' ];
$blind  = $row[ 'blind' ];

?>
                        <div class='row'>
                            <div class='col-md-10'>
                                <div class='row'>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Register No:</label>
                                        <div><b><?php echo $regno;
?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Student Name:</label>
                                        <div><b><?php echo $row[ 'name' ];
?></b>
                                        </div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <label>DOB:</label>
                                        <div><b><?php  echo $row[ 'dob' ];
?></b></div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <label>Mobile No:</label>
                                        <div><b><?php echo $row[ 'mobile_no' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Email ID:</label>
                                        <div><b><?php echo $row[ 'email' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Exam Centre:</label>
                                        <div><b><?php  echo $row[ 'centre_code' ];
?> - <?php  echo $row[ 'college_name' ];
?>

                                            </b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Course Name:</label>
                                        <div><b><?php  echo $row[ 'course' ];
?></b>
                                        </div>
                                    </div>

                                    <div class='col-md-4 inlinediv'>
                                        <label>Aadhaar No:</label>
                                        <div><b><?php echo $row[ 'adhaar_no' ] ?></b>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Blind:</label>
                                        <div>
                                            <?php if ( $row[ 'blind' ] === 'Y' ) {
    echo 'YES';
} else {
    echo 'NO';
}
?>
                                        </div>

                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Readmission:</label>
                                        <div>
                                            <?php if ( $row[ 'readmission' ] === 'Y' ) {
    echo 'YES';
} else {
    echo 'NO';
}
?>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Readmission Year:</label>
                                        <div>
                                            <?php echo $row[ 'readmission_year' ];
?>
                                        </div>
                                    </div>
                                    <div class='col-md-4 inlinediv'>
                                        <label>Re-admitted Semester:</label>
                                        <div>
                                            <?php echo $row[ 'readmission_semester' ];
?>

                                        </div>
                                    </div>
                                    <div class='col-md-12 inlinediv'>
                                        <label>Address:</label>
                                        <div>
                                            <?php echo $address;
?>

                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class='col-md-2'><img src='<?php echo $photo_url; ?>' width='150'></div>
                        </div>
                        <br> <br>
                        <h3>Details</h3>
                        <?php 


                       
$sqli = "SELECT * FROM `subject_list` where `register_no`='$regno'";
$results = $conn->query( $sqli );
 while ( $row = $results->fetch_assoc()){
$sem = $row[ 'current_semester' ];
}

                    $subjectssql = "SELECT * FROM `subject_list` WHERE `register_no` = '$regno' and `semester` = '$sem'";
                    $subjectsresult = $conn->query( $subjectssql );
                    $currentsubjects = '';
                    $i = 0;
                    
                    while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
                                $i++;
}
                    



if ( $blind === 'Y' )
 {
    $examfee = 0;
} else {
    $examfee = ($current_semsubjects_count*200)+ ($other_sem_internalcount *400 ) +  ( $other_sem_externalcount *200 ) + ( $othersubjects_count*200 ) ;

}



?>
<p>No.Subjects Enrolled :  <?php echo $subjectcount; 
$totalfee = $examfee + $Application_fee +  $Consolidated_Statement_of_Marks +  $Convocation_Fees + $Provisional_Certificate + $Statement_of_Marks + $penalty+$tatkal;

$randomid = time().rand( 111111, 999999 );
$timess = date( 'd-m-Y h:i:s a' );
$date = date( 'd-m-Y' );
$randomid = $randomid;
$order_sql = "INSERT INTO `student_order`( `exam_fee`, `register_no`, `name`,`subjects`, `no_ofsubjects`, `payment_id`, `application_fee`, `statement_of_marks`, `provisional_certificate`, `consolidated_statement_of_mark`, `convocation_fees`, `total_fee`, `payment_status`, `time`, `payment_key`, `status`, `email`, `mobile`,`date`,`penalty`,`tatkal`) VALUES ('".$examfee."','".$regno."','".$name."','".$othersubjects."','".$subjectcount."','".$randomid."','".$Application_fee."','".$Statement_of_Marks."','".$Provisional_Certificate."','".$Consolidated_Statement_of_Marks."','".$Convocation_Fees."','".$totalfee."','','".$timess."','','','".$email."','".$mobile_no."','".$date."','".$penalty."','".$tatkal."')";
$result = $conn->query( $order_sql );
$last_id = mysqli_insert_id( $conn );
?>

                        <table class='table'>
                            <tr>
                                <th colspan='3'>Current Semester Subjects:</th>
                            </tr>
                            <tr>
                                <th>Subject Code
                                </th>
                                <th>Subject Name
                                </th>
                                <th>Optional Subjects
                                </th>
                                <th>Semester
                                </th>
                            </tr><?php
while ( list( $key, $value ) = each ( $current_semsubjects ) ) {

    $subjectssql = "SELECT `subject_code`, `subject_name`, `internal_status`, `external_status`,`optional_subjects`,
                        `semester`, `id` FROM `subject_list` WHERE `register_no`='$regno' and `subject_code`='$value'";
    $subjectsresult = $conn->query( $subjectssql );
    ?>
                            <?php
    while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
        ?>
                            <tr>
                                <td> <?php echo $subjectsrow[ 'subject_code' ];
        ?>
                                </td>
                                <td><?php echo $subjectsrow[ 'subject_name' ];
        ?>

                                <td><?php echo $subjectsrow[ 'optional_subjects' ];
        ?>
                                </td>
                                <td><?php echo $subjectsrow[ 'semester' ];
        ?>
                                </td>

                            </tr> <?php
       $enroll_query = "INSERT INTO `enrolled_subjects`( `order_id`, `subject_code`, `subject_name`,`optional_subjects`, `internal_status`, `external_status`, `semester`, `subject_id` ) VALUES ( '".$last_id."', '".$subjectsrow[ 'subject_code' ]."', '".$subjectsrow[ 'subject_name' ]."','".$subjectsrow[ 'optional_subjects' ]."', '".$subjectsrow[ 'internal_status' ]."', '".$subjectsrow[ 'external_status' ]."', '".$subjectsrow[ 'semester' ]."', '".$subjectsrow[ 'id' ]."' )";
        $conn->query( $enroll_query );
    }
    ?>

      <?php
}

?>
                        </table>
                 
                        <table class='table'>
                            <tr>
                                <th colspan='3'>Arrear Semester Subjects:</th>
                            </tr>
                            <tr>
                                <th>Subject Code
                                </th>
                                <th>Subject Name
                                </th>

                                <th>Semester
                                </th>
                                <th>Internal
                                </th>
                                <th>External
                                </th>
                            </tr><?php
while ( list( $key, $value ) = each ( $other_sem ) ) {

   echo $subjectssql = "SELECT `subject_code`, `subject_name`, `internal_status`, `external_status`, `optional_subjects`,
                        `semester`, `id` FROM `subject_list` WHERE `register_no`='$regno' and `subject_code`='$value' ";
    $subjectsresult = $conn->query( $subjectssql );
    ?>

                            <?php
    while ( $subjectsrow = $subjectsresult->fetch_assoc() ) {
        ?>
                            <tr>
                                <td> <?php echo $subjectsrow[ 'subject_code' ];
        ?>
                                </td>
                                <td><?php echo $subjectsrow[ 'subject_name' ];
        ?>

                                </td>
                                <td><?php echo $subjectsrow[ 'semester' ];
        ?>
                                <td><?php if ( in_array( $subjectsrow[ 'subject_code' ], $other_sem_internal ) ) {
            $internalconfirm = 'T';
            echo '&#10004;';
        } else $internalconfirm = ''
        ?></td>
                                <td><?php if ( in_array( $subjectsrow[ 'subject_code' ], $other_sem_external ) ) {
            $externalconfirm = 'T';
            echo '&#10004;';
        } else $externalconfirm = '';
        ?>
                                </td>

                            </tr> <?php
        $enroll_query = "INSERT INTO `enrolled_subjects`( `order_id`, `subject_code`, `subject_name`,`optional_subjects`, `internal_status`, `external_status`, `semester`, `subject_id` ) VALUES ( '".$last_id."', '".$subjectsrow[ 'subject_code' ]."', '".$subjectsrow[ 'subject_name' ]."','".$subjectsrow[ 'optional_subjects' ]."', '".$internalconfirm."', '".$externalconfirm."', '".$subjectsrow[ 'semester' ]."', '".$subjectsrow[ 'id' ]."' )";
        $conn->query( $enroll_query );
    }
    ?>

                            <?php
}

?>
                        </table>
                        </p>
                        <p>Other Unlisted Subjects : <?php echo $othersubjects;
?>
                        <p>Exam Fee : <?php echo $examfee;
?></p>
                        <p>Application fee : <?php echo $Application_fee?></p>
                        <p>Statement of Marks : <?php echo $Statement_of_Marks?></p>
                        <p>Provisional Certificate : <?php echo $Provisional_Certificate?></p>
                        <p>Consolidated Statement of Marks : <?php echo $Consolidated_Statement_of_Marks?></p>
                        <p>Convocation Fees : <?php echo $Convocation_Fees?></p>
                        <p>Penalty : <?php echo $penalty;
?> </p><p>Tatkal : <?php echo $tatkal;
?> </p>
                        <p>Total Fee :
                            <b>
                                <?php echo $totalfee;
?></b>
                        </p>
                        <p>Payment Time & Date: <?php echo $timess;
?></p>
                        <?php

if ( $result ) {
    ?><form name='frmPayment' action='ccavRequestHandler.php' method='POST'>
                            <tr>

                                <td><input type='hidden' value=<?php echo $randomid;
    ?> name='tid' id='tid' readonly />
                                </td>
                            </tr>
                            <input type='hidden' name='merchant_id' value='<?php echo $CCA_MERCHANT_ID; ?>'>
                            <input type='hidden' name='language' value='EN'>
                            <input type='hidden' name='order_id' value='<?php echo $last_id;?>'>
                            <input type='hidden' name='amount' value='<?php echo $totalfee; ?>'> <input type='hidden'
                                name='merchant_param1' value='<?php echo $regno; ?>'>

                            <!-- <input type = 'hidden' name = 'amount' value = '10'> -->
                            <input type='hidden' name='currency' value='INR'>
                            <input type='hidden' name='redirect_url'
                                value='https://tndalucoe.in/examappl_dec/ccavResponseHandler.php'>
                            <input type='hidden' name='cancel_url' value='https://tndalucoe.in/examappl_dec/ccavResponseHandler.php'>

                            <div>
                                <input type='hidden' name='billing_name' value=<?php echo $name;
    ?> class='form-field' Placeholder='Billing Name'>
                                <input type='hidden' name='billing_address' value='' class='form-field'
                                    Placeholder='Billing Address'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_state' value='' class='form-field'
                                    Placeholder='State'>
                                <input type='hidden' name='billing_zip' value='' class='form-field'
                                    Placeholder='Zipcode'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_country' value='' class='form-field'
                                    Placeholder='Country'>
                                <input type='hidden' name='billing_tel' value=<?php echo $mobile_no ?>
                                    class='form-field' Placeholder='Phone'>
                            </div>
                            <div>
                                <input type='hidden' name='billing_email' value=<?php echo $email ?> class='form-field'
                                    Placeholder='Email'>
                            </div>

                            <p> <input type='checkbox' name='terms' checked onclick='return false'> I hereby declare
                                that all the details given above are correct to the best of my
                                knowledge, If any discrepancies, necessary actions shall be initiated by the University
                                against me.
                            </p>
                            <div>
                                <button class='btn btn-secondary' type='reset' onclick='history.back()'>BACK</button>
                                <button class='btn btn-primary' type='submit'>Pay Now</button>
                            </div>
                        </form>

                        <?php
}
?>
                    </div>

                </div>

            </div>
            <?php
?>

        </div>
    </div>
    <!--- Count Down End -->

</body>
<script>
function goBack() {
    window.location.hash = window.location.lasthash[window.location.lasthash.length - 1];
    //blah blah blah
    window.location.lasthash.pop();
}
</script>
<?php include( 'include/footer.php' );
?>