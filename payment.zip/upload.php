<?php
if ( array_key_exists( 'fileToUpload', $_FILES ) ) {
    $BlogImageName = '';
    $allowedExts = array( 'png', 'jpg', 'jpeg', 'gif', 'pdf', 'PDF', 'doc', 'docx', 'DOC', 'DOCX', 'xlsx', 'XLSX', 'mp4', 'avi', 'mp3', 'MP4', 'AVI', 'MP3', 'mpeg', 'PNG', 'JPG', 'JPEG', 'GIF', 'bmp', 'BMP', 'webp', 'WEBP' );
    $temp = explode( '.', $_FILES[ 'fileToUpload' ][ 'name' ] );
    $extension = end( $temp );
    if ( !in_array( $extension, $allowedExts ) ) {
        $BlogImageName = '';
    } else {
        if ( $_FILES[ 'fileToUpload' ][ 'error' ] > 0 ) {
            $errorUploadImageReturn = 1;

        } else {
            $extensionExplodeArray = explode( '.', $_FILES[ 'fileToUpload' ][ 'name' ] );
            $BlogImageName = rand(1000,9999).time().'.'.$extension;
            $BlogImagePath = 'uploads/profile/'.$BlogImageName;
            move_uploaded_file( $_FILES[ 'fileToUpload' ][ 'tmp_name' ], $BlogImagePath );
        }
    }
    echo $BlogImagePath;
}

if ( array_key_exists( 'aadhaarToUpload', $_FILES ) ) {
    $BlogImageName = '';
    $allowedExts = array( 'png', 'jpg', 'jpeg', 'gif', 'pdf', 'PDF', 'doc', 'docx', 'DOC', 'DOCX', 'xlsx', 'XLSX', 'mp4', 'avi', 'mp3', 'MP4', 'AVI', 'MP3', 'mpeg', 'PNG', 'JPG', 'JPEG', 'GIF', 'bmp', 'BMP', 'webp', 'WEBP' );
    $temp = explode( '.', $_FILES[ 'aadhaarToUpload' ][ 'name' ] );
    $extension = end( $temp );
    if ( !in_array( $extension, $allowedExts ) ) {
        $BlogImageName = '';
    } else {
        if ( $_FILES[ 'aadhaarToUpload' ][ 'error' ] > 0 ) {
            $errorUploadImageReturn = 1;

        } else {
            $extensionExplodeArray = explode( '.', $_FILES[ 'aadhaarToUpload' ][ 'name' ] );
            $BlogImageName = rand(1000,9999).time().'.'.$extension;
            $BlogImagePath = 'uploads/aadhaar/'.$BlogImageName;
            move_uploaded_file( $_FILES[ 'aadhaarToUpload' ][ 'tmp_name' ], $BlogImagePath );
        }
    }
    echo $BlogImagePath;
}
?>