<?php
session_start();
include( 'connection.php' );
if ( isset( $_POST[ 'regno' ] ) ) {
    $regno = $_POST[ 'regno' ];
}
if ( isset( $_POST[ 'password' ] ) ) {
    $password = $_POST[ 'password' ];
}
if ( isset( $_POST[ 'g-recaptcha-response' ] ) ) {
    $captcha = $_POST[ 'g-recaptcha-response' ];
}

if ( !$captcha ) {
    echo 'Please check the the captcha form.';
    exit;
}
$secretKey = '6LdQ-QMgAAAAAK7f79feBmtwruD34HIUWnxZUDgS';
$ip = $_SERVER[ 'REMOTE_ADDR' ];
// post request to server
$url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode( $secretKey ) .  '&response=' . urlencode( $captcha );
$response = file_get_contents( $url );
$responseKeys = json_decode( $response, true );
// should return JSON with success as true
if ( $responseKeys[ 'success' ] ) {
    if ( $regno !== '' )
 {
        $sql = "SELECT * FROM `students` where `register_no`='$regno' and password='$password'";
        $result = $conn->query( $sql );
        $row = $result->fetch_assoc();
        if ( isset( $row ) && count( $row ) >= 1 )
 {
            $_SESSION[ 'regno' ] = $regno;
            $_SESSION[ 'name' ] = $row[ 'name' ];
            echo 'Success';
        } else {
            echo 'Invaild Username or Password';
        }
    } else {
        //header( 'location:login.php' );
        session_destroy();
    }
} else {
    echo 'Invaild Captcha, Please Retry';
}

?>